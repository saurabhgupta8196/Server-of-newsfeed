const express = require('express');
const app = express();

const Dao = require('./modules/data-access/data-access');
const dao = new Dao();

class NewsFeed {

    async getNewsFeed(collections, userName) {
        let result = await dao.aggregate("demo1", [{ $match: { "userName": userName } }, { $project: { allValues: { $setUnion: ["$followings", "$followingCompany"] }, _id: 0 } }])
        var abc;

        var array = []
        var arrayTimestamp=[]
        var arrayPostID=[]
        result = result[0].allValues;
        console.log(result);
        for (var i of result) {
            abc = await dao.aggregate("demo1", [{ $match: { "userName": i } }, { $project: { "posts": 1, _id: 0 } }])
            //console.log(abc)
            arrayTimestamp.push(abc.map(temp => {
                return temp.posts.map(t => {
                    return (t.timestamp);
                });
            }).join());
            arrayPostID.push(abc.map(temp => {
                return temp.posts.map(t => {
                    return (t.postId);
                });
            }).join());
            // array = array.map(t => {
            //     return t;
            // })
            // array = array.filter(t => {
            //     if (t != NaN)
            //         return t
            // })
            // array = array.sort((a, b) => {
            //     return a - b;
            // })
        }
        console.log(arrayTimestamp)
         console.log(arrayPostID)
         //console.log(array);
    }


}
module.exports = NewsFeed;
